<?php

include_once "library/OAuthStore.php";
	include_once "library/OAuthRequester.php";
	include_once "SSAPICaller.php";


	$key = "J5KideU1ZfCWlyIljMKIVwjtMwLiZq"; 
	$secret = "4H7s1ExFgQLV7SqTGzN2NCoO4CyrSG";
	$base_url = "http://api.seatseller.travel/";
//$source = "2";

	echo "<form name='erw' action='AllDestination.php' method='post'>";
	echo "From: ";
	$sourceList = getSourcesAsDropDownList();
	echo $sourceList;

	if($_POST['sourceList'] != '')
	{
	echo "              To:";

	echo "selected city is: ".$_POST['sourceList'];

	$destinations= getDestinationAsDropDownList($_POST['sourceList']);
	echo $destinations;

	}
	echo "</form>";	
function getSourcesAsDropDownList()
	{
		global $scr,$sourceId,$sourcename;
		$scr = getAllSources();
		$json_o=json_decode($scr);
		$selectControlForSources = "<select onChange='submit()' id = 'sourceList' name='sourceList'>";
			if(is_array($json_o->cities))
			{
			foreach($json_o->cities as $cityToConsider)
				{
					$selectControlForSources = $selectControlForSources."<option value=". $cityToConsider->id.">"
									. $cityToConsider->name."</option>";
					}
				$selectControlForSources = $selectControlForSources."</select>";
			}
		return $selectControlForSources ;
	}
	
function getDestinationAsDropDownList($sourceId)
	{
		echo "getting destinations for".$sourceId;

		$scr = getDestinationForSource($sourceId);
		$json_o=json_decode($scr);
		$selectControlForSources = "<select onChange='submit()' id = 'sourceList' name='sourceList'>";
			if(is_array($json_o->cities))
			{
			foreach($json_o->cities as $cityToConsider)
				{
					$selectControlForSources = $selectControlForSources."<option value=". $cityToConsider->id.">"
									. $cityToConsider->name."</option>";
								
				}
				$selectControlForSources = $selectControlForSources."</select>";
			}
		return $selectControlForSources ;
	}

?>
