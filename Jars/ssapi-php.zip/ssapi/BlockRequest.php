<?php
class BlockRequest
{
var $availableTripId ;
var $boardingPointId;
var $destination;
var $inventoryItems;
var $source;
}

class inventoryItems
{
var $fare;
var $ladiesSeat;
var $passenger;
var $seatName;
}

class passenger
{
var $address;
var $age;
var $email;
var $gender;
var $idNumber;
var $idType;
var $mobile;
var $name;
var $primary;
var $title;
}
?>






